public class LoveCS
{
    public static void main(String[] args)
    {
	final int LIMIT = 10;

	int count = 1;

	while (count <= LIMIT){
	    System.out.println("I love Computer Science!!");
	    count++;
	}
    }
}
