// ****************************************************************
//   Guess.java
//
//   Play a game where the user guesses a number from 1 to 10
//          
// ****************************************************************
import java.util.Scanner;
import java.util.Random;

public class Guess
{
    public static void main(String[] args)
    {
      int numToGuess;       //Number the user tries to guess
      int guess;            //The user's guess

	Scanner scan = new Scanner(System.in);
	Random generator = new Random();

	//randomly generate the  number to guess

	//print message asking user to enter a guess

	//read in guess
                
	while (  )  //keep going as long as the guess is wrong
        {
	    //print message saying guess is wrong
	    //get another guess from the user
	}

	//print message saying guess is right
    }
}
